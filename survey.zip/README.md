# package
Laravel Package with Entrust Role Permission
