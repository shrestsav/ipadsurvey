<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('success')): ?>
  <div class="alert alert-success">
    <p><?php echo e($message); ?></p>
  </div>
<?php endif; ?>
<div class="row justify-content-xl-center">
  <div class="col-xl-8">
    <div class="card">
      <div class="card-header border-0">
        <div class="row">
          <div class="col-6">
            <h3 class="mb-0">Roles Management</h3>
          </div>
          <div class="col-6 text-right">
            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-outline-primary" data-toggle="tooltip" data-original-title="Edit product">
              <span class="btn-inner--icon"><i class="fas fa-user-edit"></i></span>
              <span class="btn-inner--text">New Role</span>
            </a>
          </div>
        </div>
      </div>
      <div class="table-responsive">
        <table class="table align-items-center table-flush">
          <thead class="thead-light">
            <tr>
              <th>S.No</th>
              <th>Roles</th>
              <th>Description</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
            <tr>
              <td class="table-user"><?php echo e(++$i); ?></td>
              <td><?php echo e($role->display_name); ?></td>
              <td><?php echo e($role->description); ?></td>
              <td class="table-actions" style="text-align: right;">
                <a class="btn btn-outline-info" href="<?php echo e(route('roles.show',$role->id)); ?>">Show</a>
                <a class="btn btn-outline-primary" href="<?php echo e(route('roles.edit',$role->id)); ?>">Edit</a>
                <form action="<?php echo e(url('admin/roles/'.$role->id)); ?>" method="POST" style="display: inline-block">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

                  <button type="submit" id="delete-task-<?php echo e($role->id); ?>" class="btn btn-outline-danger">Delete</button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ShreStsaV\Development\package\resources\views/roles/index.blade.php ENDPATH**/ ?>