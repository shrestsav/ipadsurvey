<?php $__env->startSection('content'); ?>
<div class="row justify-content-md-center">
  <div class="col-md-5">
    <div class="card-wrapper">
      <div class="card">
        <div class="card-header">
          <h3 class="mb-0">Edit User</h3>
        </div>
        <div class="card-body">
          <form class="form-horizontal needs-validation" role="form" method="POST" action="<?php echo e(url('admin/users/'.$user->id)); ?>" novalidate>
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

            <div class="form-group">
              <label class="form-control-label">Display name</label>
              <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required autofocus>
              <div class="invalid-feedback">
                Name is Required
              </div>     
              <?php if($errors->has('name')): ?>
                <div class="invalid-feedback" style="display: block;">
                  <?php echo e($errors->first('name')); ?>

                </div>
              <?php endif; ?>
            </div>            
            <div class="form-group">
              <label class="form-control-label">E-Mail</label>
              <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required autofocus>
              <div class="invalid-feedback">
                Name is Required
              </div>     
              <?php if($errors->has('email')): ?>
                <div class="invalid-feedback" style="display: block;">
                  <?php echo e($errors->first('email')); ?>

                </div>
              <?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-control-label">Password</label>
              <input type="password" class="form-control" name="password" autofocus>   
              <?php if($errors->has('password')): ?>
                <div class="invalid-feedback" style="display: block;">
                  <?php echo e($errors->first('password')); ?>

                </div>
              <?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-control-label">Confirm Password</label>
              <input type="password" class="form-control" name="password_confirmation" autofocus>   
              <?php if($errors->has('password_confirmation')): ?>
                <div class="invalid-feedback" style="display: block;">
                  <?php echo e($errors->first('password_confirmation')); ?>

                </div>
              <?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-control-label">Roles</label>
              <select id="role" name="roles[]" multiple class="form-control" multiple>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e(in_array($role->id, $userRoles) ? "selected" : null); ?>>
                        <?php echo e($role->display_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>

                <?php if($errors->has('roles')): ?>
                  <div class="invalid-feedback" style="display: block;">
                  <?php echo e($errors->first('roles')); ?>

                  </div>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-outline-success"> Update </button>
            <a class="btn btn-outline-warning" href="<?php echo e(url('admin/roles')); ?>"> Cancel </a>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ShreStsaV\Development\package\resources\views/users/edit.blade.php ENDPATH**/ ?>