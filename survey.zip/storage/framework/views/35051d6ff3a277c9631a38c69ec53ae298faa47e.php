<?php $__env->startSection('content'); ?>
<div class="row justify-content-md-center">
  <div class="col-md-5">
    <div class="card-wrapper">
      <div class="card">
        <div class="card-header">
          <h3 class="mb-0">Create New Role</h3>
        </div>
        <div class="card-body">
          <form class="form-horizontal needs-validation" role="form" method="POST" action="<?php echo e(url('admin/roles')); ?>" novalidate>
            <?php echo e(csrf_field()); ?>

            <div class="form-group<?php echo e($errors->has('display_name') ? ' has-error' : ''); ?>">
              <label class="form-control-label">Display name</label>
              <input type="text" class="form-control" placeholder="Eg:  Admin" name="display_name" value="<?php echo e(old('display_name')); ?>" required >
              <div class="invalid-feedback">
                Display Name is Required
              </div>     
              <?php if($errors->has('display_name')): ?>
                <div class="invalid-feedback" style="display: block;">
                  <?php echo e($errors->first('display_name')); ?>

                </div>
              <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
              <label class="form-control-label">Slug</label>
              <input type="text" class="form-control" placeholder="Eg:  admin" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
              <div class="invalid-feedback">
                Slug name is required
              </div> 
              <?php if($errors->has('name')): ?>
              <div class="invalid-feedback" style="display: block;">
                <?php echo e($errors->first('name')); ?>

              </div>
              <?php endif; ?>
            </div>
            <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
              <label class="form-control-label">Description</label>
              <textarea class="form-control" name="description" rows="3" required><?php echo e(old('description')); ?></textarea>
              <div class="invalid-feedback">
                Description is Required
              </div> 
              <?php if($errors->has('description')): ?>
              <div class="invalid-feedback" style="display: block;">
                <?php echo e($errors->first('description')); ?>

              </div>
              <?php endif; ?>
            </div>
            <div class="form-group<?php echo e($errors->has('permissions') ? ' has-error' : ''); ?>">
              <label for="permissions">Permissions</label>
              <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="custom-control custom-checkbox mb-3">
                <input class="custom-control-input" type="checkbox" id="permission_<?php echo e($key); ?>"  value="<?php echo e($key); ?>" name="permissions[]">
                <label class="custom-control-label" for="permission_<?php echo e($key); ?>"><?php echo e($permission); ?></label>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if($errors->has('permissions')): ?>
                <span class="help-block">
                  <strong><?php echo e($errors->first('permissions')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-outline-success"> Save </button>
            <a class="btn btn-outline-warning" href="<?php echo e(url('admin/roles')); ?>"> Cancel </a>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
  
</script>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ShreStsaV\Development\package\resources\views/roles/create.blade.php ENDPATH**/ ?>