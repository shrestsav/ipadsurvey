<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header border-0">
		<div class="row">
			<div class="col-6">
				<h3 class="mb-0">Survey Details</h3>
			</div>
			<div class="col-6 text-right">
				
			</div>
		</div>
		<br>
		<br>
		<div class="row">
			<div class="col-4">
				<h4>Name: </h3><span><?php echo e($survey->fname); ?> <?php echo e($survey->lname); ?></span>
			</div>
			<div class="col-4">
				<h4>Email: </h3><span><?php echo e($survey->email); ?></span>
			</div>
			<div class="col-4">
				<h4>Contact: </h3><span><?php echo e($survey->phone); ?></span>
			</div>
		</div>
	</div>
	<div class="card-body">
		<div class="accordion" id="accordionExample">
			<?php $__currentLoopData = $survey->survey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <div class="card">
		        <div class="card-header" id="headingOne" data-toggle="collapse" data-target="#collapse<?php echo e($key); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($key); ?>">
		            <h5 class="mb-0"><?php echo e($s['Q']); ?></h5>
		        </div>
		        <div id="collapse<?php echo e($key); ?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
		            <div class="card-body">
		            <p><?php echo e($s['A']); ?></p>
		            </div>
		        </div>
		  	</div>
		  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ShreStsaV\Development\survey\resources\views/surveyDetails.blade.php ENDPATH**/ ?>