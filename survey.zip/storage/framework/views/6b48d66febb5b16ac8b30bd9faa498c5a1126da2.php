<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header border-0">
		<div class="row">
			<div class="col-6">
				<h3 class="mb-0">Surveys</h3>
			</div>
			<div class="col-6 text-right">
				
			</div>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table align-items-center table-flush">
			<thead class="thead-light">
				<tr>
					<th>S.No</th>
					<th>Name</th>
					<th>Phone</th>
					<th>Email</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php $i=1; ?>
				<?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($i++); ?></td>
						<td><?php echo e($survey->fname); ?> <?php echo e($survey->lname); ?></td>
						<td><?php echo e($survey->phone); ?></td>
						<td><?php echo e($survey->email); ?></td>
						<td class="table-actions">
							<a href="<?php echo e(url('/surveys/'.$survey->id)); ?>" class="table-action" data-toggle="tooltip" data-original-title="View Survey">
								<i class="fas fa-eye"></i>
							</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<div class="card-footer py-4">
      <?php echo e($surveys->links()); ?>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ShreStsaV\Development\survey\resources\views/dashboard.blade.php ENDPATH**/ ?>