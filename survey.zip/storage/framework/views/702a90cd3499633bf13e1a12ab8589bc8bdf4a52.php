<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<div class="row justify-content-xl-center">
  <div class="col-xl-8">
    <div class="card">
      <div class="card-header border-0">
        <div class="row">
          <div class="col-6">
            <h3 class="mb-0">User Management</h3>
          </div>

        </div>
      </div>
      <div class="table-responsive">
        <table class="table align-items-center table-flush">
          <thead class="thead-light">
            <tr>
              <th>S.No</th>
              <th>Name</th>
              <th>Email</th>
              <th>Roles</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$i); ?></td>
              <td><?php echo e($user->name); ?></td>
              <td><?php echo e($user->email); ?></td>
              <td>
                <?php if(!empty($user->roles)): ?>
                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="label label-success"><?php echo e($role->display_name); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </td>
              <td class="table-actions" style="text-align: right;">
                <a class="btn btn-outline-info" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a>
                <a class="btn btn-outline-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>

                <form action="<?php echo e(url('admin/users/'.$user->id)); ?>" method="POST" style="display: inline-block">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

                  <button type="submit" id="delete-task-<?php echo e($user->id); ?>" class="btn btn-outline-danger"> Delete </button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <?php echo e($users->links()); ?> 
        </table>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ShreStsaV\Development\package\resources\views/users/index.blade.php ENDPATH**/ ?>