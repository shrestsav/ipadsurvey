<?php $__env->startSection('content'); ?>

<!-- contents from vue js -->
<router-view></router-view>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('vueScripts'); ?>
<!-- Vue js -->
<script type="text/javascript" src="<?php echo e(asset('js/system.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ShreStsaV\Development\survey\resources\views/test.blade.php ENDPATH**/ ?>