<?php $__env->startSection('content'); ?>
<div class="row justify-content-xl-center">
  <div class="col-xl-4">
    <div class="card">
      <div class="card-header">
        <h5 class="h3 mb-0">Role : Info</h5>
      </div>
      <div class="card-body p-0">
        <ul class="list-group list-group-flush">
          <li class="checklist-entry list-group-item flex-column align-items-start py-4 px-4">
            <div class="checklist-info">
              <h5 class="checklist-title mb-0">Name</h5>
              <small><?php echo e($role->display_name); ?></small>
            </div>
          </li>
          <li class="checklist-entry list-group-item flex-column align-items-start py-4 px-4">
            <div class="checklist-info">
              <h5 class="checklist-title mb-0">Description</h5>
              <small><?php echo e($role->description); ?></small>
            </div>
          </li>
          <li class="checklist-entry list-group-item flex-column align-items-start py-4 px-4">
            <div class="checklist-info">
              <h5 class="checklist-title mb-0">Permissions</h5><br>
              <?php if(!empty($permissions)): ?>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="btn btn-primary btn-sm"><?php echo e($permission->display_name); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ShreStsaV\Development\package\resources\views/roles/show.blade.php ENDPATH**/ ?>