<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Web Application Designed by Shrestsav">
  <meta name="author" content="<?php echo e(env('DEVELOPED_BY','ShreStsaV')); ?>">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo e(env('APP_NAME','System')); ?></title>
  <!-- Canonical SEO -->
  <link rel="canonical" href="<?php echo e(env('APP_URL')); ?>" />
  <!-- Favicon -->
  <link rel="icon" href="<?php echo e(asset('argon')); ?>/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/%40fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/vendor/animate.css/animate.min.css" type="text/css">
  <!-- Argon CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('argon')); ?>/css/argon.min9f1e.css?v=1.1.0" type="text/css">
  <style type="text/css">
    [data-notify="progressbar"] {
      margin-bottom: 0px;
      position: absolute;
      bottom: 0px;
      left: 0px;
      width: 100%;
      height: 5px;
    }
  </style>
</head>

<body>

  <div id="app">
    <!-- Sidenav -->
    <nav class="sidenav navbar navbar-vertical fixed-left navbar-expand-xs navbar-light bg-white" id="sidenav-main">

      <?php echo $__env->make('layouts.inc.__sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </nav>
    <!-- Main content -->
    <div class="main-content" id="panel">
      <!-- Topnav -->
      <nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">

        <?php echo $__env->make('layouts.inc.__header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </nav>

      
      <div class="header bg-primary pb-6">
        <div class="container-fluid">
          <div class="header-body">
            <div class="row align-items-center py-4">

              <?php echo $__env->make('layouts.inc.__breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
            <!-- Card stats -->
            <div class="row">

              <?php echo $__env->yieldContent('showcase'); ?>

            </div>
          </div>
        </div>
      </div>
      <!-- Page content -->
      <div class="container-fluid mt--6">

        <?php echo $__env->yieldContent('content'); ?>

        <!-- Footer -->
        <footer class="footer pt-0">

          <?php echo $__env->make('layouts.inc.__footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
        </footer>
      </div>
    </div>
  </div>
  
  <?php echo $__env->yieldPushContent('vueScripts'); ?>
  <!-- Core -->
  <script src="<?php echo e(asset('argon')); ?>/vendor/jquery/dist/jquery.min.js"></script>
  <script src="<?php echo e(asset('argon')); ?>/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo e(asset('argon')); ?>/vendor/js-cookie/js.cookie.js"></script>
  <script src="<?php echo e(asset('argon')); ?>/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="<?php echo e(asset('argon')); ?>/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
   <!-- Argon JS -->
  <script src="<?php echo e(asset('argon')); ?>/js/argon.min9f1e.js?v=1.1.0"></script>
  <script src="<?php echo e(asset('system')); ?>/js/bootstrap-notify.min.js"></script>
  <script src="<?php echo e(asset('system')); ?>/js/app.js"></script>
  <script type="text/javascript">
      <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          showNotify('danger','<?php echo e($error); ?>')
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>

      <?php if(\Session::has('error')): ?>
        showNotify('danger','<?php echo e(\Session::get("error")); ?>')
      <?php endif; ?>

      <?php if(\Session::has('message')): ?>
        showNotify('success','<?php echo e(\Session::get("message")); ?>')
      <?php endif; ?>

      <?php if(\Session::has('success')): ?>
        showNotify('success','<?php echo e(\Session::get("success")); ?>')
      <?php endif; ?>
  </script>
  <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH E:\ShreStsaV\Development\package\resources\views/layouts/app.blade.php ENDPATH**/ ?>